package ch.walica.a56_temp201126_3tp1_btn;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private Button btnChange, btnShowHide;
    private TextView tvText1, tvText2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        btnChange = findViewById(R.id.btnChange);
        btnShowHide = findViewById(R.id.btnShowHide);
        tvText1 = findViewById(R.id.tvText1);
        tvText2 = findViewById(R.id.tvText2);

        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setMyTextView(12);
            }
        });

        btnShowHide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(tvText1.getVisibility() == View.VISIBLE) {
                    tvText1.setVisibility(View.INVISIBLE);
                    btnShowHide.setText("Pokaż");
                } else {
                    tvText1.setVisibility(View.VISIBLE);
                    btnShowHide.setText("Ukryj");
                }

            }
        });


    }

    private void setMyTextView(float textSize) {
        tvText2.setBackgroundColor(Color.rgb(34, 156, 255));
        tvText2.setText("To jest nowy tekst");
        tvText2.setTextSize(textSize);
    }
}