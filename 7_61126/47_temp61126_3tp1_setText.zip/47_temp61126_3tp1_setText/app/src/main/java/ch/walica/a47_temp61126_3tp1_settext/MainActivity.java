package ch.walica.a47_temp61126_3tp1_settext;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tvText1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvText1 = findViewById(R.id.tvText1);

        tvText1.setText("To jest nowy tekst");
        tvText1.setBackgroundColor(Color.RED);
        tvText1.setTextColor(getColor(R.color.color_1));
        tvText1.setBackgroundColor(Color.rgb(55, 51, 178));
        tvText1.setTextSize(32);

    }
}